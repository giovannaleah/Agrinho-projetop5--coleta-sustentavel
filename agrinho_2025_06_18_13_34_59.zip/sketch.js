// Jogo Agrinho 2025 - Coleta Sustentável
let player;
let recyclables = [];
let nonRecyclables = [];
let score = 0;
let timeLeft = 30; // Tempo em segundos

function setup() {
  createCanvas(800, 600);
  player = new Player();
  
  for (let i = 0; i < 10; i++) {
    recyclables.push(new Item(random(width), random(height), true));
    nonRecyclables.push(new Item(random(width), random(height), false));
  }

  setInterval(() => {
    if (timeLeft > 0) {
      timeLeft--;
    }
  }, 1000);
}

function draw() {
  background(100, 200, 100);

  if (timeLeft <= 0) {
    textSize(32);
    fill(255);
    textAlign(CENTER, CENTER);
    text(`Fim de Jogo! Pontuação: ${score}`, width / 2, height / 2);
    noLoop();
    return;
  }

  // Mostrar tempo restante e pontuação
  textSize(20);
  fill(0);
  text(`Pontuação: ${score}`, 10, 20);
  text(`Tempo restante: ${timeLeft}s`, 10, 50);

  player.display();
  player.move();

  // Exibir e verificar coleta de recicláveis
  for (let i = recyclables.length - 1; i >= 0; i--) {
    recyclables[i].display();
    if (player.collects(recyclables[i])) {
      score += 10;
      recyclables.splice(i, 1);
    }
  }

  // Exibir e verificar coleta de não-recicláveis
  for (let i = nonRecyclables.length - 1; i >= 0; i--) {
    nonRecyclables[i].display();
    if (player.collects(nonRecyclables[i])) {
      score -= 5;
      nonRecyclables.splice(i, 1);
    }
  }
}

class Player {
  constructor() {
    this.x = width / 2;
    this.y = height / 2;
    this.size = 50;
  }

  display() {
    fill(0, 0, 255);
    ellipse(this.x, this.y, this.size);
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) this.x -= 5;
    if (keyIsDown(RIGHT_ARROW)) this.x += 5;
    if (keyIsDown(UP_ARROW)) this.y -= 5;
    if (keyIsDown(DOWN_ARROW)) this.y += 5;

    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  collects(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < this.size / 2 + item.size / 2;
  }
}

class Item {
  constructor(x, y, isRecyclable) {
    this.x = x;
    this.y = y;
    this.size = 30;
    this.isRecyclable = isRecyclable;
  }

  display() {
    if (this.isRecyclable) {
      fill(0, 255, 0);
    } else {
      fill(255, 0, 0);
    }
    ellipse(this.x, this.y, this.size);
  }
}
